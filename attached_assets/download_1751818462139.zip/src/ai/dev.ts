import { config } from 'dotenv';
config();

import '@/ai/flows/fraud-assessment.ts';
'use server';

/**
 * @fileOverview AI-powered fraud risk assessment flow.
 *
 * - fraudAssessment - A function that handles the fraud assessment process.
 * - FraudAssessmentInput - The input type for the fraudAssessment function.
 * - FraudAssessmentOutput - The return type for the fraudAssessment function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const FraudAssessmentInputSchema = z.object({
  transactionAmount: z.number().describe('The amount of the transaction.'),
  transactionType: z.string().describe('The type of the transaction (e.g., online purchase, wire transfer).'),
  customerLocation: z.string().describe('The location of the customer.'),
  merchantLocation: z.string().describe('The location of the merchant.'),
  transactionTime: z.string().describe('The time of the transaction (e.g., day of the week, time of day).'),
});
export type FraudAssessmentInput = z.infer<typeof FraudAssessmentInputSchema>;

const FraudAssessmentOutputSchema = z.object({
  isFraudulent: z.boolean().describe('Whether or not the transaction is likely to be fraudulent.'),
  riskScore: z.number().describe('A score indicating the risk of fraud (0-100).'),
  explanation: z.string().describe('An explanation of why the transaction is considered fraudulent or not.'),
});
export type FraudAssessmentOutput = z.infer<typeof FraudAssessmentOutputSchema>;

export async function fraudAssessment(input: FraudAssessmentInput): Promise<FraudAssessmentOutput> {
  return fraudAssessmentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'fraudAssessmentPrompt',
  input: {schema: FraudAssessmentInputSchema},
  output: {schema: FraudAssessmentOutputSchema},
  prompt: `You are an AI fraud detection expert. Analyze the transaction details provided and determine the likelihood of fraud.

Transaction Amount: {{{transactionAmount}}}
Transaction Type: {{{transactionType}}}
Customer Location: {{{customerLocation}}}
Merchant Location: {{{merchantLocation}}}
Transaction Time: {{{transactionTime}}}

Based on this information, assess the risk of fraud and provide a risk score (0-100), a boolean isFraudulent to represent the assessment and a detailed explanation.
`,
});

const fraudAssessmentFlow = ai.defineFlow(
  {
    name: 'fraudAssessmentFlow',
    inputSchema: FraudAssessmentInputSchema,
    outputSchema: FraudAssessmentOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);

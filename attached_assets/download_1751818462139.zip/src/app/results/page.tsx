import { MetricsDisplay } from '@/components/pages/results/MetricsDisplay';
import { FraudReductionChart } from '@/components/pages/results/FraudReductionChart';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function ResultsPage() {
  return (
    <div className="bg-background">
      <div className="container py-20 md:py-24">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="font-headline text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            Proven Results. Tangible Impact.
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">
            FraudHunt delivers measurable improvements to your security posture and your bottom line. Our data speaks for itself.
          </p>
        </div>

        <MetricsDisplay />

        <div className="mt-16">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="font-headline">Fraud Incidents Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <FraudReductionChart />
              </div>
            </CardContent>
          </Card>
        </div>
         <div className="mt-16 text-center">
            <p className="text-muted-foreground">
              *All metrics based on aggregated data from our client base in Q2 {new Date().getFullYear()}. Results may vary.
            </p>
        </div>
      </div>
    </div>
  );
}

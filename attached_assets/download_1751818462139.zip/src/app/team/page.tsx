import { TeamMemberCard } from '@/components/pages/team/TeamMemberCard';

const teamMembers = [
  {
    name: 'Dr. Evelyn Reed',
    role: 'Founder & CEO',
    bio: 'With a Ph.D. in AI and two decades in cybersecurity, Evelyn leads our mission to outsmart financial criminals.',
    imageSrc: 'https://placehold.co/400x400.png',
    dataAiHint: 'woman ceo',
  },
  {
    name: 'Ben Carter',
    role: 'Chief Technology Officer',
    bio: 'The architect of our agentic AI platform. Ben turns complex theories into scalable, real-world solutions.',
    imageSrc: 'https://placehold.co/400x400.png',
    dataAiHint: 'man developer',
  },
  {
    name: 'Olivia Martinez',
    role: 'Head of Product',
    bio: 'Olivia ensures FraudHunt is not only powerful but also intuitive and seamlessly integrated for our clients.',
    imageSrc: 'https://placehold.co/400x400.png',
    dataAiHint: 'woman product manager',
  },
  {
    name: 'Samuel Jones',
    role: 'VP of Sales & Partnerships',
    bio: 'Samuel builds bridges with our clients, ensuring their security needs are met and exceeded.',
    imageSrc: 'https://placehold.co/400x400.png',
    dataAiHint: 'man sales',
  },
   {
    name: 'Aisha Khan',
    role: 'Lead Data Scientist',
    bio: 'Aisha trains our AI models, teaching them to identify and adapt to the ever-changing landscape of fraud.',
    imageSrc: 'https://placehold.co/400x400.png',
    dataAiHint: 'woman scientist',
  },
   {
    name: 'David Lee',
    role: 'Head of Customer Success',
    bio: 'David is dedicated to our clients\' success, providing expert support and strategic guidance.',
    imageSrc: 'https://placehold.co/400x400.png',
    dataAiHint: 'man support',
  },
];

export default function TeamPage() {
  return (
    <div className="bg-background">
      <div className="container py-20 md:py-24">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="font-headline text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            Meet the Minds Behind FraudHunt
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">
            We are a passionate team of AI researchers, security experts, and product visionaries dedicated to making the digital economy safer for everyone.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {teamMembers.map((member, index) => (
            <TeamMemberCard key={index} {...member} />
          ))}
        </div>
      </div>
    </div>
  );
}

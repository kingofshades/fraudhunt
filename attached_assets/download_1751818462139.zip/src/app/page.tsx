import { HeroSection } from '@/components/pages/home/HeroSection';
import { FeaturesSection } from '@/components/pages/home/FeaturesSection';
import { BenefitsSection } from '@/components/pages/home/BenefitsSection';
import { TestimonialsSection } from '@/components/pages/home/TestimonialsSection';
import { CtaSection } from '@/components/pages/home/CtaSection';

export default function Home() {
  return (
    <>
      <HeroSection />
      <FeaturesSection />
      <BenefitsSection />
      <TestimonialsSection />
      <CtaSection />
    </>
  );
}

import { fraudAssessment, FraudAssessmentInput } from '@/ai/flows/fraud-assessment';
import { FraudDemoForm } from '@/components/pages/demo/FraudDemoForm';

export type FormState = {
  success: boolean;
  message: string;
  data?: {
    isFraudulent: boolean;
    riskScore: number;
    explanation: string;
  }
} | null;

async function assessFraudAction(_prevState: FormState, formData: FormData): Promise<FormState> {
  'use server';
  
  const rawFormData = {
    transactionAmount: Number(formData.get('transactionAmount')),
    transactionType: formData.get('transactionType') as string,
    customerLocation: formData.get('customerLocation') as string,
    merchantLocation: formData.get('merchantLocation') as string,
    transactionTime: formData.get('transactionTime') as string,
  };

  try {
    const result = await fraudAssessment(rawFormData as FraudAssessmentInput);
    return { success: true, message: 'Assessment complete.', data: result };
  } catch (error) {
    console.error(error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
    return { success: false, message: `Error assessing fraud: ${errorMessage}` };
  }
}

export default function DemoPage() {
  return (
    <div className="bg-background">
      <div className="container py-20 md:py-24">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="font-headline text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            AI Fraud Assessment Demo
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">
            Experience the power of FraudHunt's AI firsthand. Input the transaction details below to see a simulated fraud risk assessment in real-time.
          </p>
        </div>

        <div className="mt-12 mx-auto max-w-4xl">
          <FraudDemoForm assessFraudAction={assessFraudAction} />
        </div>
      </div>
    </div>
  );
}

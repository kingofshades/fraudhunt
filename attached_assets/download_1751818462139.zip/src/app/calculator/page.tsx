import { RevenueCalculator } from "@/components/pages/calculator/RevenueCalculator";
import { Card, CardContent, CardHeader, CardDescription, CardTitle } from "@/components/ui/card";
import { DollarSign, BarChart, Shield } from "lucide-react";

export default function CalculatorPage() {
    return (
        <div className="bg-background">
            <div className="container py-20 md:py-24">
                <div className="mx-auto max-w-3xl text-center">
                    <h1 className="font-headline text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
                        Calculate Your Potential ROI
                    </h1>
                    <p className="mt-4 text-lg text-muted-foreground">
                        Use our interactive calculator to estimate how much revenue you could recover and how many hours you could save by implementing FraudHunt.
                    </p>
                </div>

                <div className="mt-16 grid grid-cols-1 gap-12 md:grid-cols-5">
                    <div className="md:col-span-3">
                         <Card className="shadow-lg">
                            <CardHeader>
                                <CardTitle className="font-headline">Revenue Recovery Calculator</CardTitle>
                                <CardDescription>Adjust the sliders to match your business metrics.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <RevenueCalculator />
                            </CardContent>
                        </Card>
                    </div>
                    <div className="md:col-span-2 space-y-8">
                        <Card className="shadow-md">
                            <CardHeader className="flex flex-row items-center justify-between pb-2">
                                <CardTitle className="text-sm font-medium font-headline">Why This Matters</CardTitle>
                                <DollarSign className="h-4 w-4 text-muted-foreground" />
                            </CardHeader>
                            <CardContent>
                                <p className="text-sm text-muted-foreground">Every fraudulent transaction prevented is pure profit restored to your bottom line.</p>
                            </CardContent>
                        </Card>
                         <Card className="shadow-md">
                            <CardHeader className="flex flex-row items-center justify-between pb-2">
                                <CardTitle className="text-sm font-medium font-headline">Industry Benchmarks</CardTitle>
                                <BarChart className="h-4 w-4 text-muted-foreground" />
                            </CardHeader>
                            <CardContent>
                                <p className="text-sm text-muted-foreground">The average e-commerce store loses 1-2% of its annual revenue to fraud. How do you stack up?</p>
                            </CardContent>
                        </Card>
                         <Card className="shadow-md">
                            <CardHeader className="flex flex-row items-center justify-between pb-2">
                                <CardTitle className="text-sm font-medium font-headline">Beyond the Numbers</CardTitle>
                                <Shield className="h-4 w-4 text-muted-foreground" />
                            </CardHeader>
                            <CardContent>
                                <p className="text-sm text-muted-foreground">Reduced fraud also means fewer customer disputes, better bank relationships, and a stronger brand reputation.</p>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        </div>
    );
}

import Link from 'next/link';
import { Twitter, Linkedin, Facebook } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { Button } from '@/components/ui/button';

export function Footer() {
  return (
    <footer className="bg-card">
      <div className="container py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="md:col-span-1">
            <Logo />
            <p className="mt-4 text-sm text-muted-foreground">
              AI-powered fraud detection to secure your business.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-8 md:col-span-3 md:grid-cols-4">
            <div>
              <h3 className="font-headline text-sm font-semibold tracking-wider text-foreground">Product</h3>
              <ul className="mt-4 space-y-2">
                <li><Link href="/features" className="text-sm text-muted-foreground hover:text-primary">Features</Link></li>
                <li><Link href="/results" className="text-sm text-muted-foreground hover:text-primary">Results</Link></li>
                <li><Link href="/demo" className="text-sm text-muted-foreground hover:text-primary">Demo</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-headline text-sm font-semibold tracking-wider text-foreground">Company</h3>
              <ul className="mt-4 space-y-2">
                <li><Link href="/team" className="text-sm text-muted-foreground hover:text-primary">About Us</Link></li>
                <li><Link href="/team" className="text-sm text-muted-foreground hover:text-primary">Team</Link></li>
                <li><Link href="#" className="text-sm text-muted-foreground hover:text-primary">Careers</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-headline text-sm font-semibold tracking-wider text-foreground">Resources</h3>
              <ul className="mt-4 space-y-2">
                <li><Link href="#" className="text-sm text-muted-foreground hover:text-primary">Blog</Link></li>
                <li><Link href="#" className="text-sm text-muted-foreground hover:text-primary">Case Studies</Link></li>
                <li><Link href="#" className="text-sm text-muted-foreground hover:text-primary">Whitepapers</Link></li>
              </ul>
            </div>
             <div>
              <h3 className="font-headline text-sm font-semibold tracking-wider text-foreground">Legal</h3>
              <ul className="mt-4 space-y-2">
                <li><Link href="#" className="text-sm text-muted-foreground hover:text-primary">Privacy Policy</Link></li>
                <li><Link href="#" className="text-sm text-muted-foreground hover:text-primary">Terms of Service</Link></li>
              </ul>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} FraudHunt, Inc. All rights reserved.
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <Button variant="ghost" size="icon" asChild>
                <Link href="#" aria-label="Twitter"><Twitter className="h-5 w-5 text-muted-foreground hover:text-primary" /></Link>
            </Button>
            <Button variant="ghost" size="icon" asChild>
                <Link href="#" aria-label="LinkedIn"><Linkedin className="h-5 w-5 text-muted-foreground hover:text-primary" /></Link>
            </Button>
            <Button variant="ghost" size="icon" asChild>
                <Link href="#" aria-label="Facebook"><Facebook className="h-5 w-5 text-muted-foreground hover:text-primary" /></Link>
            </Button>
          </div>
        </div>
      </div>
    </footer>
  );
}

import Image from 'next/image';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Linkedin, Twitter } from 'lucide-react';

interface TeamMemberCardProps {
  name: string;
  role: string;
  bio: string;
  imageSrc: string;
  dataAiHint: string;
}

export function TeamMemberCard({ name, role, bio, imageSrc, dataAiHint }: TeamMemberCardProps) {
  return (
    <Card className="text-center overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300">
      <CardHeader className="p-0">
        <Image
          src={imageSrc}
          alt={`Photo of ${name}`}
          width={400}
          height={400}
          className="aspect-square w-full object-cover"
          data-ai-hint={dataAiHint}
        />
      </CardHeader>
      <CardContent className="p-6">
        <CardTitle className="font-headline">{name}</CardTitle>
        <CardDescription className="text-primary">{role}</CardDescription>
        <p className="mt-4 text-sm text-muted-foreground">{bio}</p>
      </CardContent>
      <CardFooter className="flex justify-center gap-2 bg-card pb-6">
         <Button variant="ghost" size="icon" asChild>
            <Link href="#" aria-label={`${name}'s Twitter`}>
                <Twitter className="h-5 w-5 text-muted-foreground hover:text-primary" />
            </Link>
        </Button>
         <Button variant="ghost" size="icon" asChild>
            <Link href="#" aria-label={`${name}'s LinkedIn`}>
                <Linkedin className="h-5 w-5 text-muted-foreground hover:text-primary" />
            </Link>
        </Button>
      </CardFooter>
    </Card>
  );
}

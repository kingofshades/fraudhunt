import { Button } from '@/components/ui/button';
import Link from 'next/link';

export function CtaSection() {
  return (
    <section className="py-20 md:py-32 bg-primary text-primary-foreground">
      <div className="container text-center">
        <h2 className="font-headline text-3xl font-bold tracking-tight sm:text-4xl">
          Ready to Secure Your Revenue?
        </h2>
        <p className="mt-4 mx-auto max-w-2xl text-lg text-primary-foreground/80">
          Discover how FraudHunt's agentic AI can protect your business from evolving fraud threats. Schedule a personalized demo with our experts today.
        </p>
        <div className="mt-8">
          <Button size="lg" variant="secondary" asChild>
            <Link href="/demo">
              Schedule Your Free Demo
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

import Image from 'next/image';
import { CheckCircle } from 'lucide-react';

const benefits = [
  'Reduce chargebacks by up to 90%',
  'Increase transaction approval rates',
  'Protect your brand reputation and customer trust',
  'Automate manual review processes',
];

export function BenefitsSection() {
  return (
    <section className="py-20 md:py-32 bg-background">
      <div className="container grid grid-cols-1 items-center gap-12 md:grid-cols-2">
        <div className="flex justify-center">
          <Image
            src="https://placehold.co/600x400.png"
            alt="Graph showing increased revenue"
            width={600}
            height={400}
            className="rounded-xl shadow-2xl"
            data-ai-hint="revenue graph"
          />
        </div>
        <div className="space-y-6">
          <h2 className="font-headline text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Turn Security into a Revenue Driver
          </h2>
          <p className="max-w-xl text-lg text-muted-foreground">
            FraudHunt doesn't just prevent losses; it helps you confidently accept more legitimate transactions, boosting your top line.
          </p>
          <ul className="space-y-4">
            {benefits.map((benefit, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="mr-3 mt-1 h-5 w-5 flex-shrink-0 text-primary" />
                <span>{benefit}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

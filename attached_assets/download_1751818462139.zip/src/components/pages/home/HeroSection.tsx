import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';
import { ShieldCheck, TrendingUp } from 'lucide-react';

export function HeroSection() {
  return (
    <section className="bg-background py-20 md:py-32">
      <div className="container grid grid-cols-1 items-center gap-12 md:grid-cols-2">
        <div className="space-y-6">
          <h1 className="font-headline text-4xl font-bold tracking-tighter text-foreground sm:text-5xl md:text-6xl">
            Stop Fraud in Its Tracks with AI
          </h1>
          <p className="max-w-xl text-lg text-muted-foreground">
            FraudHunt leverages cutting-edge agentic AI to analyze transactions in real-time, protecting your revenue and customer trust with unparalleled accuracy.
          </p>
          <div className="flex flex-col gap-4 sm:flex-row">
            <Button size="lg" asChild>
              <Link href="/demo">
                <ShieldCheck className="mr-2 h-5 w-5" />
                Request a Demo
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/results">
                <TrendingUp className="mr-2 h-5 w-5" />
                View Our Results
              </Link>
            </Button>
          </div>
        </div>
        <div className="flex justify-center">
          <Image
            src="https://placehold.co/600x400.png"
            alt="Fraud Detection Dashboard"
            width={600}
            height={400}
            className="rounded-xl shadow-2xl"
            data-ai-hint="fraud detection security"
          />
        </div>
      </div>
    </section>
  );
}

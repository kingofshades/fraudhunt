import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Bot, Zap, Clock, Network } from 'lucide-react';

const features = [
  {
    icon: <Bot className="h-8 w-8 text-primary" />,
    title: 'Agentic AI Analysis',
    description: 'Our AI agents think like human analysts, uncovering complex fraud patterns other systems miss.',
  },
  {
    icon: <Zap className="h-8 w-8 text-primary" />,
    title: 'Real-Time Detection',
    description: 'Analyze and block fraudulent transactions in milliseconds, before they impact your bottom line.',
  },
  {
    icon: <Clock className="h-8 w-8 text-primary" />,
    title: 'Adaptive Learning',
    description: 'The system continuously learns from new data, staying ahead of evolving fraud tactics.',
  },
  {
    icon: <Network className="h-8 w-8 text-primary" />,
    title: 'Seamless Integration',
    description: 'Easily integrate FraudHunt into your existing payment gateways with our robust APIs.',
  },
];

export function FeaturesSection() {
  return (
    <section id="features" className="py-20 md:py-32 bg-card">
      <div className="container">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="font-headline text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Why FraudHunt is Different
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            We go beyond simple rule-based systems to provide a dynamic, intelligent fraud prevention solution.
          </p>
        </div>
        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <Card key={index} className="flex flex-col items-center text-center p-6 shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                  {feature.icon}
                </div>
                <CardTitle className="font-headline">{feature.title}</CardTitle>
              </CardHeader>
              <CardDescription>{feature.description}</CardDescription>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Star } from 'lucide-react';

const testimonials = [
  {
    name: 'Sarah Johnson',
    title: 'CFO, E-commerce Giant',
    quote: "FraudHunt revolutionized our approach to fraud. We've seen a 75% reduction in chargebacks and our manual review team can now focus on strategic initiatives.",
    avatar: 'SJ',
    image: 'https://placehold.co/100x100.png'
  },
  {
    name: 'Michael Chen',
    title: 'Head of Payments, Fintech Startup',
    quote: "The integration was seamless, and the results were immediate. FraudHunt's AI is smarter and faster than any other solution we've tried. It's a must-have.",
    avatar: 'MC',
    image: 'https://placehold.co/100x100.png'
  },
  {
    name: 'Jessica Rodriguez',
    title: 'Founder, Subscription Box Co.',
    quote: "As a growing business, we were a prime target for fraud. FraudHunt gave us enterprise-level security at a scale that works for us. I can sleep better at night.",
    avatar: 'JR',
    image: 'https://placehold.co/100x100.png'
  },
];

export function TestimonialsSection() {
  return (
    <section className="py-20 md:py-32 bg-card">
      <div className="container">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="font-headline text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Trusted by Industry Leaders
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            See what our partners have to say about securing their revenue with FraudHunt.
          </p>
        </div>
        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="flex flex-col justify-between p-6 shadow-md">
              <div>
                <div className="flex text-accent">
                    {[...Array(5)].map((_, i) => <Star key={i} className="h-5 w-5 fill-current" />)}
                </div>
                <CardContent className="p-0 pt-4">
                  <p className="italic text-muted-foreground">"{testimonial.quote}"</p>
                </CardContent>
              </div>
              <div className="mt-6 flex items-center">
                <Avatar>
                  <AvatarImage src={testimonial.image} alt={testimonial.name} data-ai-hint="person" />
                  <AvatarFallback>{testimonial.avatar}</AvatarFallback>
                </Avatar>
                <div className="ml-4">
                  <p className="font-semibold text-foreground">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.title}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

'use client';

import { useState, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { TrendingUp, ShieldCheck, Clock } from 'lucide-react';

export function RevenueCalculator() {
  const [monthlyRevenue, setMonthlyRevenue] = useState(500000);
  const [fraudRate, setFraudRate] = useState(1.5);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };
  
  const formattedMonthlyRevenue = useMemo(() => formatCurrency(monthlyRevenue), [monthlyRevenue]);

  const annualLoss = monthlyRevenue * 12 * (fraudRate / 100);
  const potentialSavings = annualLoss * 0.75; // Assuming 75% reduction
  const manualReviewHoursSaved = (monthlyRevenue / 1000) * (fraudRate / 100) * 50; // A proxy for saved hours

  const ResultCard = ({ icon, title, value, description }: { icon: React.ReactNode, title: string, value: string, description: string }) => (
    <Card className="bg-primary/5">
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
            <div className="bg-primary/10 p-2 rounded-md">
                {icon}
            </div>
            <div>
                <p className="text-sm text-muted-foreground">{title}</p>
                <p className="text-2xl font-bold font-headline text-primary">{value}</p>
                <p className="text-xs text-muted-foreground">{description}</p>
            </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <div className="flex justify-between items-center">
            <Label htmlFor="monthly-revenue">Monthly Revenue</Label>
            <span className="font-bold text-lg font-headline text-primary">{formattedMonthlyRevenue}</span>
        </div>
        <Slider
          id="monthly-revenue"
          min={10000}
          max={5000000}
          step={10000}
          value={[monthlyRevenue]}
          onValueChange={(value) => setMonthlyRevenue(value[0])}
        />
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
            <Label htmlFor="fraud-rate">Current Fraud Rate</Label>
            <span className="font-bold text-lg font-headline text-primary">{fraudRate.toFixed(2)}%</span>
        </div>
        <Slider
          id="fraud-rate"
          min={0.1}
          max={5}
          step={0.1}
          value={[fraudRate]}
          onValueChange={(value) => setFraudRate(value[0])}
        />
      </div>
      
      <div className="pt-4 border-t border-border">
          <h3 className="text-center font-headline mb-4">Estimated Annual Impact</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <ResultCard 
                icon={<TrendingUp className="h-6 w-6 text-primary" />}
                title="Potential Revenue Recovered"
                value={formatCurrency(potentialSavings)}
                description="By reducing chargebacks & false declines."
            />
            <ResultCard 
                icon={<ShieldCheck className="h-6 w-6 text-primary" />}
                title="Annual Fraud Loss Prevented"
                value={formatCurrency(annualLoss)}
                description="Directly adds to your bottom line."
            />
            <ResultCard 
                icon={<Clock className="h-6 w-6 text-primary" />}
                title="Manual Review Hours Saved"
                value={`${Math.round(manualReviewHoursSaved).toLocaleString()}+`}
                description="Freeing up your team for growth."
            />
          </div>
      </div>
    </div>
  );
}

'use client';

import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ChartContainer, ChartTooltipContent } from '@/components/ui/chart';

const chartData = [
  { month: 'Jan', before: 4000, after: 2400 },
  { month: 'Feb', before: 3000, after: 1398 },
  { month: 'Mar', before: 2000, after: 980 },
  { month: 'Apr', before: 2780, after: 890 },
  { month: 'May', before: 1890, after: 480 },
  { month: 'Jun', before: 2390, after: 380 },
];

const chartConfig = {
    before: {
        label: "Before FraudHunt",
        color: "hsl(var(--muted-foreground))",
    },
    after: {
        label: "After FraudHunt",
        color: "hsl(var(--primary))",
    },
};

export function FraudReductionChart() {
  return (
    <ChartContainer config={chartConfig} className="w-full h-full">
        <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip content={<ChartTooltipContent />} />
                <Legend />
                <Bar dataKey="before" fill="var(--color-before)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="after" fill="var(--color-after)" radius={[4, 4, 0, 0]} />
            </BarChart>
        </ResponsiveContainer>
    </ChartContainer>
  );
}

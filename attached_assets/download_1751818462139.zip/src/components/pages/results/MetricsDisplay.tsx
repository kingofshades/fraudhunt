import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, ShieldCheck, CheckCircle } from 'lucide-react';

const metrics = [
  {
    icon: <TrendingUp className="h-8 w-8 text-primary" />,
    title: '99.8% Accuracy',
    description: 'In identifying fraudulent transactions, minimizing false positives.',
  },
  {
    icon: <ShieldCheck className="h-8 w-8 text-primary" />,
    title: '75% Chargeback Reduction',
    description: 'Average reduction in chargeback rates for our clients within 3 months.',
  },
  {
    icon: <CheckCircle className="h-8 w-8 text-primary" />,
    title: '3% Revenue Uplift',
    description: 'Average increase in approved transactions by safely reducing false declines.',
  },
];

export function MetricsDisplay() {
  return (
    <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-3">
      {metrics.map((metric, index) => (
        <Card key={index} className="text-center shadow-md hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="mx-auto mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              {metric.icon}
            </div>
            <CardTitle className="font-headline text-2xl">{metric.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">{metric.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

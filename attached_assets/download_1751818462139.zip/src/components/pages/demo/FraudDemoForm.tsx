'use client';

import { useFormState, useFormStatus } from 'react-dom';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { useEffect } from 'react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import type { FormState } from '@/app/demo/page';
import { Bot, AlertTriangle, CheckCircle, Shield, TrendingDown, TrendingUp } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

const formSchema = z.object({
  transactionAmount: z.coerce.number().min(1, 'Amount must be at least 1.'),
  transactionType: z.string().min(1, 'Please select a transaction type.'),
  customerLocation: z.string().min(2, 'Customer location is required.'),
  merchantLocation: z.string().min(2, 'Merchant location is required.'),
  transactionTime: z.string().min(1, 'Please select a transaction time.'),
});

type FraudDemoFormProps = {
  assessFraudAction: (prevState: FormState, formData: FormData) => Promise<FormState>;
};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending} className="w-full">
      {pending ? (
        <>
          <Bot className="mr-2 h-4 w-4 animate-spin" />
          Assessing...
        </>
      ) : (
        <>
          <Bot className="mr-2 h-4 w-4" />
          Assess Fraud Risk
        </>
      )}
    </Button>
  );
}

export function FraudDemoForm({ assessFraudAction }: FraudDemoFormProps) {
  const { toast } = useToast();
  const [state, formAction] = useFormState(assessFraudAction, null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      transactionAmount: 1250.75,
      transactionType: 'Wire Transfer',
      customerLocation: 'New York, USA',
      merchantLocation: 'Jakarta, Indonesia',
      transactionTime: 'Late Night (12am-4am)',
    },
  });

  useEffect(() => {
    if (state && !state.success) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: state.message,
      });
    }
  }, [state, toast]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
      <Card className="shadow-lg">
        <Form {...form}>
          <form action={form.handleSubmit(data => formAction(new FormData(form.control.ownerDocument.activeElement?.form)))} className="space-y-8">
            <CardHeader>
              <CardTitle className="font-headline">Transaction Details</CardTitle>
              <CardDescription>Fill in the fields to simulate a transaction.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="transactionAmount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Transaction Amount (USD)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="e.g., 450.50" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="transactionType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Transaction Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Select a type" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Online Purchase">Online Purchase</SelectItem>
                        <SelectItem value="Wire Transfer">Wire Transfer</SelectItem>
                        <SelectItem value="In-person (Card)">In-person (Card)</SelectItem>
                        <SelectItem value="Subscription">Subscription</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="customerLocation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Customer Location</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., London, UK" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="merchantLocation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Merchant Location</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Singapore" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="transactionTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time of Transaction</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Select a time" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Morning (5am-12pm)">Morning (5am-12pm)</SelectItem>
                        <SelectItem value="Afternoon (12pm-5pm)">Afternoon (12pm-5pm)</SelectItem>
                        <SelectItem value="Evening (5pm-12am)">Evening (5pm-12am)</SelectItem>
                        <SelectItem value="Late Night (12am-5am)">Late Night (12am-5am)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
            <CardFooter>
              <SubmitButton />
            </CardFooter>
          </form>
        </Form>
      </Card>

      <Card className="shadow-lg sticky top-24">
         <CardHeader>
            <CardTitle className="font-headline">AI Assessment Result</CardTitle>
            <CardDescription>The AI's analysis will appear here.</CardDescription>
        </CardHeader>
        <CardContent>
            {!state || !state.data ? (
                <div className="flex flex-col items-center justify-center text-center text-muted-foreground p-8 space-y-4 border-2 border-dashed rounded-lg h-full">
                    <Shield className="h-12 w-12" />
                    <p>Awaiting transaction for analysis...</p>
                </div>
            ) : (
                <div className="space-y-4">
                     <Alert variant={state.data.isFraudulent ? "destructive" : "default"} className={!state.data.isFraudulent ? "border-green-500/50 text-green-700 dark:text-green-400" : ""}>
                         {state.data.isFraudulent ? <AlertTriangle className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
                        <AlertTitle className="font-headline">
                            {state.data.isFraudulent ? "High Fraud Risk Detected" : "Transaction Appears Legitimate"}
                        </AlertTitle>
                        <AlertDescription>
                            {state.data.isFraudulent ? "This transaction is likely fraudulent." : "This transaction shows no signs of fraud."}
                        </AlertDescription>
                    </Alert>
                    
                    <div className="space-y-2">
                        <div className="flex justify-between items-baseline">
                            <Label>Risk Score</Label>
                            <span className={`font-bold font-headline text-lg ${state.data.riskScore > 70 ? 'text-destructive' : state.data.riskScore > 40 ? 'text-yellow-600' : 'text-green-600'}`}>
                                {state.data.riskScore} / 100
                            </span>
                        </div>
                        <Progress value={state.data.riskScore} className="h-3 [&>div]:bg-gradient-to-r [&>div]:from-green-500 [&>div]:via-yellow-500 [&>div]:to-red-500" />
                    </div>

                    <div className="pt-4">
                        <h4 className="font-semibold font-headline text-foreground">AI Explanation:</h4>
                        <p className="text-sm text-muted-foreground italic mt-1 p-3 bg-muted rounded-md">{state.data.explanation}</p>
                    </div>
                </div>
            )}
        </CardContent>
      </Card>
    </div>
  );
}

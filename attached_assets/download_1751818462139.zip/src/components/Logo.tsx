import { ShieldCheck } from 'lucide-react';
import Link from 'next/link';

export function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2" aria-label="FraudHunt Home">
      <ShieldCheck className="h-8 w-8 text-primary" />
      <span className="text-xl font-headline font-semibold text-primary">FraudHunt</span>
    </Link>
  );
}

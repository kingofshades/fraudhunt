# **App Name**: FraudHunt Landing

## Core Features:

- Landing Page: Landing page with clear calls to action, designed to showcase fraud detection capabilities.
- Results Showcase: Results page, displaying success rates and metrics on how FraudHunt reduces fraud for businesses.
- Revenue Recovery Calculator: Interactive tools demonstrating potential revenue recovery from preventing fraud.
- Team Page: Team page, showing team bios and profiles. This is will be displayed on the main naviagation for user.
- Multi-Page Design: Multiple page navigation to split the information architecture for better user engagement.
- AI Fraud Assessment Demo: A demo fraud detection 'tool', so users can have their input 'assessed' in a simulation with possible fraud outcome.

## Style Guidelines:

- Primary color: Fintech Blue (#3F51B5), conveying trust and innovation.
- Background color: Light blue (#E8EAF6), a very desaturated version of the primary.
- Accent color: Purple (#7E57C2), a visually distinct analogous hue used for interactive elements.
- Font pairing: 'Poppins' (sans-serif) for headlines and 'PT Sans' (sans-serif) for body text. 'Poppins' is modern and 'PT Sans' gives more readablity.
- Sections that follow the information architecture of the image. Sections include key features, benefit display, customer reviews, team showcase, and contact/CTA sections. A slider may be used to visualize 'Potential Revenue Recovery'
- Clean and professional icons to represent fraud detection processes, success metrics, and industries served.
- Subtle transitions and animations to highlight data visualizations and interactive elements.